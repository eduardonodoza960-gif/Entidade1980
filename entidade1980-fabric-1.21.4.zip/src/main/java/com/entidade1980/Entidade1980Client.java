package com.entidade1980;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class Entidade1980Client implements ClientModInitializer {
    public static KeyBinding OPEN_KEY;
    private static boolean glowApplied = false;

    // Abre o painel ao apertar B 3 vezes seguidas (intervalo máx. entre toques abaixo).
    private static final int PRESSES_TO_OPEN = 3;
    private static final long MAX_GAP_MS = 600;
    private static int pressCount = 0;
    private static long lastPressMs = 0;

    @Override
    public void onInitializeClient() {
        OPEN_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.entidade1980.open",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_B,
                "category.entidade1980"));

        ClientTickEvents.END_CLIENT_TICK.register(Entidade1980Client::onTick);
    }

    private static void onTick(MinecraftClient client) {
        while (OPEN_KEY.wasPressed()) {
            long now = System.currentTimeMillis();
            if (now - lastPressMs > MAX_GAP_MS) pressCount = 0;
            lastPressMs = now;
            pressCount++;
            if (pressCount >= PRESSES_TO_OPEN) {
                pressCount = 0;
                client.setScreen(new PanelScreen());
            }
        }

        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null) {
            glowApplied = false;
            return;
        }

        // Velocidade e destaque só funcionam em mundo próprio (singleplayer).
        boolean singleplayer = client.isInSingleplayer();

        // --- Destaque de entidades (glowing) ---
        boolean wantGlow = singleplayer && PanelState.glowEnabled;
        if (wantGlow) {
            for (Entity e : client.world.getEntities()) {
                if (e != player && e instanceof LivingEntity) e.setGlowing(true);
            }
            glowApplied = true;
        } else if (glowApplied) {
            for (Entity e : client.world.getEntities()) {
                if (e != player) e.setGlowing(false);
            }
            glowApplied = false;
        }

        // --- Velocidade ---
        if (singleplayer && PanelState.speedEnabled && player.isOnGround()
                && (player.input.movementForward != 0 || player.input.movementSideways != 0)) {
            Vec3d v = player.getVelocity();
            double h = Math.sqrt(v.x * v.x + v.z * v.z);
            double cap = 0.28 * PanelState.speedMultiplier;
            if (h > 0.001 && h < cap) {
                double scale = Math.min(h * 1.15, cap) / h;
                player.setVelocity(v.x * scale, v.y, v.z * scale);
            }
        }
    }
}
