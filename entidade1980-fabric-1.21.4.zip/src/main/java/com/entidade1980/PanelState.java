package com.entidade1980;

/** Estado simples do painel (posição e opções). */
public final class PanelState {
    public static int panelX = 40;
    public static int panelY = 40;

    public static boolean speedEnabled = false;
    public static float speedMultiplier = 1.5f; // 1.0 a 3.0

    public static boolean glowEnabled = false;

    private PanelState() {}
}
