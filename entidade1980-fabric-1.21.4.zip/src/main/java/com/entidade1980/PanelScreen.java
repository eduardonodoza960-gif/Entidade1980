package com.entidade1980;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

/** Painel flutuante e arrastável. Arraste pela barra de título. */
public class PanelScreen extends Screen {
    private static final int W = 200;
    private static final int H = 150;
    private static final int TITLE_H = 20;

    private boolean dragging = false;
    private double dragOffX, dragOffY;

    private FovSlider fovSlider;
    private SpeedSlider speedSlider;
    private ButtonWidget speedButton;
    private ButtonWidget glowButton;

    public PanelScreen() {
        super(Text.literal("Entidade1980"));
    }

    @Override
    protected void init() {
        clampPanel();
        int x = PanelState.panelX, y = PanelState.panelY;

        fovSlider = addDrawableChild(new FovSlider(x + 10, y + 28, W - 20, 20));
        speedSlider = addDrawableChild(new SpeedSlider(x + 10, y + 52, W - 20, 20));

        speedButton = addDrawableChild(ButtonWidget.builder(speedLabel(), b -> {
            PanelState.speedEnabled = !PanelState.speedEnabled;
            b.setMessage(speedLabel());
        }).dimensions(x + 10, y + 76, W - 20, 20).build());

        glowButton = addDrawableChild(ButtonWidget.builder(glowLabel(), b -> {
            PanelState.glowEnabled = !PanelState.glowEnabled;
            b.setMessage(glowLabel());
        }).dimensions(x + 10, y + 100, W - 20, 20).build());
    }

    private static Text speedLabel() {
        return Text.literal("Velocidade: " + (PanelState.speedEnabled ? "ON" : "OFF"));
    }

    private static Text glowLabel() {
        return Text.literal("Destacar entidades: " + (PanelState.glowEnabled ? "ON" : "OFF"));
    }

    private void clampPanel() {
        PanelState.panelX = Math.max(0, Math.min(PanelState.panelX, width - W));
        PanelState.panelY = Math.max(0, Math.min(PanelState.panelY, height - H));
    }

    private void relayout() {
        clampPanel();
        int x = PanelState.panelX, y = PanelState.panelY;
        fovSlider.setPosition(x + 10, y + 28);
        speedSlider.setPosition(x + 10, y + 52);
        speedButton.setPosition(x + 10, y + 76);
        glowButton.setPosition(x + 10, y + 100);
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        // Sem escurecer/blur: o painel flutua sobre o jogo.
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        int x = PanelState.panelX, y = PanelState.panelY;

        context.fill(x, y, x + W, y + H, 0xD0101018);
        context.fill(x, y, x + W, y + TITLE_H, 0xFF2B2B5E);
        context.drawBorder(x, y, W, H, 0xFF6C6CFF);
        context.drawText(textRenderer, Text.literal("Entidade1980 - Painel Oficial"), x + 8, y + 6, 0xFFFFFFFF, true);

        super.render(context, mouseX, mouseY, delta);

        MinecraftClient client = MinecraftClient.getInstance();
        if (!client.isInSingleplayer()) {
            context.drawText(textRenderer, Text.literal("Velocidade/destaque: só singleplayer"),
                    x + 10, y + 128, 0xFFFF5555, false);
        } else {
            context.drawText(textRenderer, Text.literal("Arraste pela barra azul"),
                    x + 10, y + 128, 0xFFAAAAAA, false);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int x = PanelState.panelX, y = PanelState.panelY;
        if (button == 0 && mouseX >= x && mouseX <= x + W && mouseY >= y && mouseY <= y + TITLE_H) {
            dragging = true;
            dragOffX = mouseX - x;
            dragOffY = mouseY - y;
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (dragging && button == 0) {
            PanelState.panelX = (int) (mouseX - dragOffX);
            PanelState.panelY = (int) (mouseY - dragOffY);
            relayout();
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (Entidade1980Client.OPEN_KEY.matchesKey(keyCode, scanCode)) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false; // o jogo continua rodando atrás do painel
    }

    // ---------- Sliders ----------

    private static class FovSlider extends SliderWidget {
        FovSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(),
                    (MinecraftClient.getInstance().options.getFov().getValue() - 30) / 80.0);
            updateMessage();
        }

        private int fov() {
            return 30 + (int) Math.round(value * 80);
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal("FOV: " + fov()));
        }

        @Override
        protected void applyValue() {
            MinecraftClient.getInstance().options.getFov().setValue(fov());
        }
    }

    private static class SpeedSlider extends SliderWidget {
        SpeedSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Text.empty(), (PanelState.speedMultiplier - 1.0) / 2.0);
            updateMessage();
        }

        private float mult() {
            return (float) (1.0 + value * 2.0);
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal(String.format("Multiplicador: %.1fx", mult())));
        }

        @Override
        protected void applyValue() {
            PanelState.speedMultiplier = mult();
        }
    }
}
